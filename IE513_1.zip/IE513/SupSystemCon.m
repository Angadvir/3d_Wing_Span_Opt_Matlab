%Supersystem nonlinear constraints in posynomial form

function[gSup, hSup] = SupSystemCon(x)
global subSys1, global subSys2

gSup = [((x(8) - subSys1(5))^2 + (x(8) - subSys2(2))^2) / x(9) - 1; %epsilon1
        ((x(3) - subSys1(1))^2 / x(10)) - 1;   %epsilon2
        ((x(6) - subSys2(1))^2 / x(11)) - 1;    %epsilon3
        ((x(3)^(-2) + x(4)^2) / x(5)^2) - 1;  %g1
        ((x(5)^2 + x(6)^(-2)) / x(7)^2) - 1]; %g2

hSup = [(x(3)^2 + x(4)^(-2) + x(5)^2) / (x(1)^2) - 1; %h1
        (x(5)^2 + x(6)^2 + x(7)^2) / (x(2)^2) - 1];   %h2 
end