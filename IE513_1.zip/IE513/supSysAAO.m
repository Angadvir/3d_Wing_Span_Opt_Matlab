function[f1] = supSysAAO(x)
f1 = x(3)^2 + x(4)^-2+2*(x(5)^2)+x(6)^2 +x(7)^2;
end