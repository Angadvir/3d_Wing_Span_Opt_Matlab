%Supersystem nonlinear constraints in posynomial form

function[gSup, hSup] = supSysCon(x)
global subSys1, global subSys2

gSup = [((x(8) - subSys1(5))^2 + (x(8) - subSys2(2))^2) / x(9) - 1; %epsilon1
        ((x(3) - subSys1(1))^2 / x(10)) - 1;    %epsilon2
        ((x(6) - subSys2(1))^2 / x(11)) - 1;    %epsilon3
        ((x(3)^(-2) + x(4)^2) / x(5)^2) - 1;    %g1
        ((x(5)^2 + x(6)^(-2)) / x(7)^2) - 1];   %g2
%          abs(x(3)-subSys1(1)-0.01);             %g3
%          abs(x(6)-subSys2(1)-0.01);             %g4  
%          abs(x(8)-subSys1(5)-0.01);             %g5
%          abs(x(8)-subSys2(2)-0.01)];            %g6  

hSup = [(x(3)^2 + x(4)^(-2) + x(5)^2) / (x(1)^2) - 1; %h1
        (x(5)^2 + x(6)^2 + x(7)^2) / (x(2)^2) - 1];   %h2 
end