%Subsystem 1 nonlinear constraints
function[gSub1, hSub1] = subSys1Con(x)
gSub1 = [((x(2)^2 + x(3)^2) / x(5)^2) - 1;     %--->g3
         ((x(2)^(-2) + x(4)^2) / x(5)^2) - 1]; %--->g4

hSub1 = (x(2)^2 + x(3)^(-2) + x(4)^(-2)+ x(5)^2) / x(1)^2 - 1; %--->h3
end