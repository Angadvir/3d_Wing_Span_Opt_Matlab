% Initial supersystem minimization function

function[f1] = supSys0(x)
f1 = x (1)^2 + x (2)^2;
end