%Initial supersystem nonlinear constraints in posynomial form 
% - excluding deviation terms

function[gSup, hSup] = SupSysIter1(x)
gSup = [((x(3)^(-2) + x(4)^2) / x(5)^2) - 1;  %g1
        ((x(5)^2 + x(6)^(-2)) / x(7)^2) - 1]; %g2

hSup = [(x(3)^2 + x(4)^(-2) + x(5)^2) / x(1)^2 - 1; %h1
        (x(5)^2 + x(6)^2 + x(7)^2) / x(2)^2 - 1];   %h2  
end