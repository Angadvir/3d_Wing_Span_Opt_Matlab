% Subsystem 1 minimization function

function[f2] = subSys1(x)
% global xSup,global c,
global v, global w, global xSup, global c
c(3) = (xSup(8)-x(5) + xSup(3)-x(1));
phi_1= v(2)*c(3) + (w(2)*c(3))^2;
f2 = w(2)*w(2)*(x(1) - xSup(3))^2 + w(3)*w(3)*(x(5) - xSup(8))^2 + phi_1;
%c(3) = (xSup(8)-x(1) + xSup(3)-x(1));
% f2 =(v(2)*((xSup(8)-x(1)+xSup(3)-x(1)))+(w(2)*w(2)*(xSup(8)-x(1)+xSup(3)-x(1))*(xSup(8)-x(1) + xSup(3)-x(1))));
end  % c(3) = ((xSup(8)-x(5) + xSup(3)-x(1)) 

% Script file for Pss1 objective function

% function obj = ATC_PS1(x,v,w,z)
% 
% c3 = (z(11)-x(11)) + (z(11)-x(11));
% phi_2 = v*c3 + (w*c3)^2;
% obj = (x(3)-z(3))^2 + (x(11)-z(11))^2 +phi_2
