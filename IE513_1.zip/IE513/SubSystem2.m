%Subsystem 2 minimization function

function[f3] = SubSystem2(x)
%global xSup, global c,
global xSup
%f3 = (v(3)*(x(1)-xSup(6)) + x(2)-xSup(8))+(w(3)*w(3)*(x(1)-xSup(6) + x(2)-xSup(8))*(x(1)-xSup(6) + x(2)-xSup(8)));
%c(4)=(x(1)-xSup(6)) + x(2)-xSup(8)) 
f3 = (x(1) - xSup(6))^2 + (x(2) - xSup(8))^2;  
end 