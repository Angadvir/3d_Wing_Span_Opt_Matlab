%Subsystem 1 minimization function

function[f2] = SubSystem1(x)
%global xSup,global c,
global xSup
f2 = (x(1) - xSup(3))^2 + (x(5) - xSup(8))^2;
%f2 =(v(2)*((xSup(8)-x(1) + xSup(3)-x(1))) + (w(2)*w(2)*(xSup(8)-x(1) + xSup(3)-x(1))*(xSup(8)-x(1) + xSup(3)-x(1))));
end  % c(3) = ((xSup(8)-x(1) + xSup(3)-x(1)) 