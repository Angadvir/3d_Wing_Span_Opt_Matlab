%Supersystem minimization function

function[f1] = SupSysOPT(x)
global v, global w, global subSys1, global subSys2, global c,
f1 = x(1)^2 + x(2)^2 + 100*(x(12) + x(13) + x(14));
%f1 = x(1)^2 + x(2)^2 + 100*(x(9)+x(10)+x(11))+(v(1)*((x(8)-subSys1(5)+x(3)-subSys1(1))+(x(8) - subSys2(2)+x(6)-subSys2(1))))+...
%(w(1)*w(1)*(((x(8)-subSys1(5)+ x(3)-subSys1(1))*(x(8)-subSys1(5) + x(3)-subSys1(1)))+((x(8) - subSys2(2)+x(6)-subSys2(1))*...
%(x(8) - subSys2(2)+ x(6)-subSys2(1)))));
%c(1) = (x(8) - subSys1(5)+x(3)-SubSys(1))
%c(2) = (x(8) - subSys2(2)+x(6)-SubSys(1))
end    