%Subsystem 2 nonlinear constraints in posynomial form
function[gSub2, hSub2] = subSys2Con(x)
gSub2 = [((x(2)^2 + x(3)^(-2)) / x(4)^2) - 1; %g5
         (x(3)^2 + x(4)^2) / x(5)^2 - 1];     %g6

hSub2 = (x(2)^2 + x(3)^2 + x(4)^2 ... %h4
            + x(5)^2) / x(1)^2 - 1;
end