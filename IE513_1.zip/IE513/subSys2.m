% Subsystem 2 minimization function

function[f3] = subSys2(x)
% global xSup, global c,
global v, global w, global c, global xSup
% f3 = (v(3)*(x(1)-xSup(6)) + x(2)-xSup(8))+(w(3)*w(3)*(x(1)-xSup(6) + x(2)-xSup(8))*(x(1)-xSup(6) + x(2)-xSup(8)));
c(4)=(x(1)-xSup(6)+x(2)-xSup(8));
phi_2= v(3)*(x(1)+x(2)) + (w(3)*c(4))^2;
f3 = w(3)*w(3)*(x(1) - xSup(6))^2 + w(3)*w(3)*(x(2) - xSup(8))^2 + phi_2;
%(v(3)*(xSup(6)-x(1) + xSup(8)-x(2)));
%c(4)=(xSup(6)-x(1) + xSup(8)-x(2)); % c(4)=(x(1)-xSup(6)) + x(2)-xSup(8)) 
end 